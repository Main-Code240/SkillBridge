/*
# SkillBridge Core Schema

## Overview
Creates the complete database schema for the SkillBridge Academia-Industry Collaboration Portal.
All tables use RLS with auth.uid()-based ownership checks.

## Tables Created
1. profiles — extends auth.users with role (student/academician/industry/institution/admin), name, phone, avatar, status
2. skill_categories — categories for skills (Technical, Soft Skills, Domain, etc.)
3. skills — individual skills linked to categories
4. assessments — assessment configurations
5. assessment_questions — questions for assessments
6. assessment_attempts — student attempts at assessments
7. skill_profiles — student skill scores with levels and verification status
8. learning_programs — recommended learning content
9. opportunities — internships, jobs, apprenticeships, etc.
10. applications — student applications to opportunities
11. internships — internship records after selection
12. internship_progress — progress tracking for internships
13. mentor_feedback — feedback from mentors
14. certificates — student certificates
15. projects — student projects
16. collaborations — academia-industry collaboration records
17. notifications — user notifications

## Security
- RLS enabled on every table
- Owner-scoped CRUD policies using auth.uid()
- Public read access on skills, skill_categories, learning_programs, opportunities (for browsing)
- Students own their profiles, skill profiles, applications, internships, certificates, projects, documents
- Industries own their opportunities and collaborations
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  role text NOT NULL CHECK (role IN ('student', 'academician', 'industry', 'institution', 'admin')),
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  avatar_url text DEFAULT '',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  is_profile_complete boolean NOT NULL DEFAULT false,
  institution text DEFAULT '',
  degree text DEFAULT '',
  department text DEFAULT '',
  graduation_year int DEFAULT NULL,
  location text DEFAULT '',
  linkedin_url text DEFAULT '',
  github_url text DEFAULT '',
  portfolio_url text DEFAULT '',
  bio text DEFAULT '',
  company_name text DEFAULT '',
  industry_type text DEFAULT '',
  company_size text DEFAULT '',
  website_url text DEFAULT '',
  institution_name text DEFAULT '',
  designation text DEFAULT '',
  specialization text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ SKILL CATEGORIES ============
CREATE TABLE IF NOT EXISTS skill_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text DEFAULT '',
  icon text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE skill_categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_skill_categories" ON skill_categories;
CREATE POLICY "read_skill_categories" ON skill_categories FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_skill_categories" ON skill_categories;
CREATE POLICY "insert_skill_categories" ON skill_categories FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_skill_categories" ON skill_categories;
CREATE POLICY "update_skill_categories" ON skill_categories FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ============ SKILLS ============
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category_id uuid REFERENCES skill_categories(id) ON DELETE SET NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_skills" ON skills;
CREATE POLICY "read_skills" ON skills FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_skills" ON skills;
CREATE POLICY "insert_skills" ON skills FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_skills" ON skills;
CREATE POLICY "update_skills" ON skills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ============ ASSESSMENTS ============
CREATE TABLE IF NOT EXISTS assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  category_id uuid REFERENCES skill_categories(id) ON DELETE SET NULL,
  skill_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  assessment_type text NOT NULL DEFAULT 'technical' CHECK (assessment_type IN ('technical', 'aptitude', 'communication', 'problem_solving', 'soft_skills', 'domain_knowledge')),
  difficulty text NOT NULL DEFAULT 'intermediate' CHECK (difficulty IN ('beginner', 'intermediate', 'advanced', 'expert')),
  time_limit_minutes int DEFAULT 30,
  passing_score int DEFAULT 50,
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_assessments" ON assessments;
CREATE POLICY "read_assessments" ON assessments FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_assessments" ON assessments;
CREATE POLICY "insert_assessments" ON assessments FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_assessments" ON assessments;
CREATE POLICY "update_assessments" ON assessments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ============ ASSESSMENT QUESTIONS ============
CREATE TABLE IF NOT EXISTS assessment_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  question_type text NOT NULL DEFAULT 'mcq' CHECK (question_type IN ('mcq', 'true_false', 'short_answer')),
  options jsonb DEFAULT '[]',
  correct_answer text DEFAULT '',
  weight int DEFAULT 1,
  difficulty text DEFAULT 'intermediate',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE assessment_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_assessment_questions" ON assessment_questions;
CREATE POLICY "read_assessment_questions" ON assessment_questions FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_assessment_questions" ON assessment_questions;
CREATE POLICY "insert_assessment_questions" ON assessment_questions FOR INSERT TO authenticated WITH CHECK (true);

-- ============ ASSESSMENT ATTEMPTS ============
CREATE TABLE IF NOT EXISTS assessment_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  score int NOT NULL DEFAULT 0,
  percentage int NOT NULL DEFAULT 0,
  skill_level text DEFAULT 'beginner' CHECK (skill_level IN ('beginner', 'intermediate', 'advanced', 'expert')),
  total_questions int DEFAULT 0,
  correct_answers int DEFAULT 0,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('in_progress', 'completed')),
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz DEFAULT now()
);
ALTER TABLE assessment_attempts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_attempts" ON assessment_attempts;
CREATE POLICY "select_own_attempts" ON assessment_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_attempts" ON assessment_attempts;
CREATE POLICY "insert_own_attempts" ON assessment_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_attempts" ON assessment_attempts;
CREATE POLICY "update_own_attempts" ON assessment_attempts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ SKILL PROFILES ============
CREATE TABLE IF NOT EXISTS skill_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  skill_name text NOT NULL,
  category text DEFAULT '',
  score int NOT NULL DEFAULT 0,
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner', 'intermediate', 'advanced', 'expert')),
  source text NOT NULL DEFAULT 'assessment' CHECK (source IN ('assessment', 'certification', 'project', 'internship', 'academician_verification', 'industry_verification', 'manual')),
  is_verified boolean NOT NULL DEFAULT false,
  verified_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE skill_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_skill_profiles" ON skill_profiles;
CREATE POLICY "select_own_skill_profiles" ON skill_profiles FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_skill_profiles" ON skill_profiles;
CREATE POLICY "insert_own_skill_profiles" ON skill_profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_skill_profiles" ON skill_profiles;
CREATE POLICY "update_own_skill_profiles" ON skill_profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_skill_profiles" ON skill_profiles;
CREATE POLICY "delete_own_skill_profiles" ON skill_profiles FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ LEARNING PROGRAMS ============
CREATE TABLE IF NOT EXISTS learning_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  skills_taught jsonb DEFAULT '[]',
  level text DEFAULT 'beginner' CHECK (level IN ('beginner', 'intermediate', 'advanced', 'expert')),
  duration_weeks int DEFAULT 4,
  provider text DEFAULT '',
  certification_available boolean DEFAULT false,
  url text DEFAULT '',
  cost text DEFAULT 'Free',
  category text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE learning_programs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_learning_programs" ON learning_programs;
CREATE POLICY "read_learning_programs" ON learning_programs FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_learning_programs" ON learning_programs;
CREATE POLICY "insert_learning_programs" ON learning_programs FOR INSERT TO authenticated WITH CHECK (true);

-- ============ OPPORTUNITIES ============
CREATE TABLE IF NOT EXISTS opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  company_name text NOT NULL DEFAULT '',
  title text NOT NULL,
  description text DEFAULT '',
  opportunity_type text NOT NULL CHECK (opportunity_type IN ('internship', 'job', 'apprenticeship', 'live_project', 'industrial_training', 'workshop', 'mentorship', 'guest_lecture', 'innovation_challenge', 'faculty_internship', 'research_collaboration')),
  required_skills jsonb DEFAULT '[]',
  preferred_skills jsonb DEFAULT '[]',
  eligibility text DEFAULT '',
  education text DEFAULT '',
  experience text DEFAULT '',
  location text DEFAULT '',
  work_mode text DEFAULT 'onsite' CHECK (work_mode IN ('onsite', 'remote', 'hybrid')),
  duration text DEFAULT '',
  stipend text DEFAULT '',
  salary text DEFAULT '',
  application_deadline date DEFAULT NULL,
  num_positions int DEFAULT 1,
  start_date date DEFAULT NULL,
  end_date date DEFAULT NULL,
  contact_email text DEFAULT '',
  contact_phone text DEFAULT '',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('draft', 'open', 'closed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE opportunities ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_opportunities" ON opportunities;
CREATE POLICY "read_opportunities" ON opportunities FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_opportunities" ON opportunities;
CREATE POLICY "insert_own_opportunities" ON opportunities FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_opportunities" ON opportunities;
CREATE POLICY "update_own_opportunities" ON opportunities FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_opportunities" ON opportunities;
CREATE POLICY "delete_own_opportunities" ON opportunities FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ APPLICATIONS ============
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  opportunity_id uuid NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
  cover_letter text DEFAULT '',
  resume_url text DEFAULT '',
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'shortlisted', 'interview', 'selected', 'rejected', 'withdrawn')),
  match_score int DEFAULT 0,
  matched_skills jsonb DEFAULT '[]',
  missing_skills jsonb DEFAULT '[]',
  industry_notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_applications" ON applications;
CREATE POLICY "select_own_applications" ON applications FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_applications" ON applications;
CREATE POLICY "insert_own_applications" ON applications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_applications" ON applications;
CREATE POLICY "update_own_applications" ON applications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ INTERNSHIPS ============
CREATE TABLE IF NOT EXISTS internships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES applications(id) ON DELETE SET NULL,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  opportunity_id uuid REFERENCES opportunities(id) ON DELETE SET NULL,
  company_name text NOT NULL DEFAULT '',
  title text NOT NULL,
  mentor_name text DEFAULT '',
  mentor_email text DEFAULT '',
  start_date date DEFAULT NULL,
  end_date date DEFAULT NULL,
  goals jsonb DEFAULT '[]',
  status text NOT NULL DEFAULT 'started' CHECK (status IN ('started', 'in_progress', 'mentor_feedback', 'final_evaluation', 'completed', 'cancelled')),
  progress int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE internships ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_internships" ON internships;
CREATE POLICY "select_own_internships" ON internships FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_internships" ON internships;
CREATE POLICY "insert_own_internships" ON internships FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_internships" ON internships;
CREATE POLICY "update_own_internships" ON internships FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ INTERNSHIP PROGRESS ============
CREATE TABLE IF NOT EXISTS internship_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  internship_id uuid NOT NULL REFERENCES internships(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  completed_at timestamptz DEFAULT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE internship_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_progress" ON internship_progress;
CREATE POLICY "select_own_progress" ON internship_progress FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = internship_progress.internship_id AND internships.user_id = auth.uid())
);

DROP POLICY IF EXISTS "insert_own_progress" ON internship_progress;
CREATE POLICY "insert_own_progress" ON internship_progress FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = internship_progress.internship_id AND internships.user_id = auth.uid())
);

DROP POLICY IF EXISTS "update_own_progress" ON internship_progress;
CREATE POLICY "update_own_progress" ON internship_progress FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = internship_progress.internship_id AND internships.user_id = auth.uid())
) WITH CHECK (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = internship_progress.internship_id AND internships.user_id = auth.uid())
);

-- ============ MENTOR FEEDBACK ============
CREATE TABLE IF NOT EXISTS mentor_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  internship_id uuid NOT NULL REFERENCES internships(id) ON DELETE CASCADE,
  mentor_name text NOT NULL DEFAULT '',
  rating int DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  strengths text DEFAULT '',
  improvements text DEFAULT '',
  comments text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE mentor_feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_feedback" ON mentor_feedback;
CREATE POLICY "select_own_feedback" ON mentor_feedback FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = mentor_feedback.internship_id AND internships.user_id = auth.uid())
);

DROP POLICY IF EXISTS "insert_own_feedback" ON mentor_feedback;
CREATE POLICY "insert_own_feedback" ON mentor_feedback FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM internships WHERE internships.id = mentor_feedback.internship_id AND internships.user_id = auth.uid())
);

-- ============ CERTIFICATES ============
CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  issuer text NOT NULL DEFAULT '',
  issue_date date DEFAULT NULL,
  expiry_date date DEFAULT NULL,
  certificate_url text DEFAULT '',
  skill_name text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_certificates" ON certificates;
CREATE POLICY "select_own_certificates" ON certificates FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_certificates" ON certificates;
CREATE POLICY "insert_own_certificates" ON certificates FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_certificates" ON certificates;
CREATE POLICY "delete_own_certificates" ON certificates FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ PROJECTS ============
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  project_url text DEFAULT '',
  repo_url text DEFAULT '',
  skills_used jsonb DEFAULT '[]',
  start_date date DEFAULT NULL,
  end_date date DEFAULT NULL,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_projects" ON projects;
CREATE POLICY "select_own_projects" ON projects FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_projects" ON projects;
CREATE POLICY "insert_own_projects" ON projects FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_projects" ON projects;
CREATE POLICY "update_own_projects" ON projects FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_projects" ON projects;
CREATE POLICY "delete_own_projects" ON projects FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ============ COLLABORATIONS ============
CREATE TABLE IF NOT EXISTS collaborations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  collaboration_type text NOT NULL CHECK (collaboration_type IN ('mentorship', 'guest_lecture', 'workshop', 'research', 'consultancy', 'innovation_challenge', 'live_project', 'industrial_training', 'fdp')),
  institution text DEFAULT '',
  industry text DEFAULT '',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('draft', 'open', 'active', 'completed', 'cancelled')),
  start_date date DEFAULT NULL,
  end_date date DEFAULT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE collaborations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_collaborations" ON collaborations;
CREATE POLICY "read_collaborations" ON collaborations FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_collaborations" ON collaborations;
CREATE POLICY "insert_own_collaborations" ON collaborations FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_collaborations" ON collaborations;
CREATE POLICY "update_own_collaborations" ON collaborations FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ NOTIFICATIONS ============
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'info' CHECK (type IN ('info', 'success', 'warning', 'error', 'opportunity', 'application', 'internship', 'feedback', 'certificate', 'collaboration')),
  is_read boolean NOT NULL DEFAULT false,
  link text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notifications" ON notifications;
CREATE POLICY "insert_own_notifications" ON notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_skills_category ON skills(category_id);
CREATE INDEX IF NOT EXISTS idx_assessments_category ON assessments(category_id);
CREATE INDEX IF NOT EXISTS idx_assessment_attempts_user ON assessment_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_skill_profiles_user ON skill_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_type ON opportunities(opportunity_type);
CREATE INDEX IF NOT EXISTS idx_opportunities_status ON opportunities(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_user ON opportunities(user_id);
CREATE INDEX IF NOT EXISTS idx_applications_user ON applications(user_id);
CREATE INDEX IF NOT EXISTS idx_applications_opportunity ON applications(opportunity_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_internships_user ON internships(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_certificates_user ON certificates(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);

-- ============ UPDATED_AT TRIGGER ============
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_opportunities_updated_at ON opportunities;
CREATE TRIGGER update_opportunities_updated_at BEFORE UPDATE ON opportunities FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_applications_updated_at ON applications;
CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON applications FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_internships_updated_at ON internships;
CREATE TRIGGER update_internships_updated_at BEFORE UPDATE ON internships FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();