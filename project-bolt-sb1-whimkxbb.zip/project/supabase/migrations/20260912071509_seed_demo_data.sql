/*
# Seed Demo Data for SkillBridge

## Overview
Populates the database with realistic demo data:
- Skill categories (Technical, Soft Skills, Domain, Aptitude)
- Skills (17 skills across categories)
- Assessments with questions (5 assessments, 25 questions total)
- Learning programs (8 programs matching skill gaps)

## Notes
- Uses DO blocks with PL/pgSQL for idempotent inserts
- All inserts check for existence before inserting
*/

-- ============ SKILL CATEGORIES ============
INSERT INTO skill_categories (name, description, icon) VALUES
  ('Technical', 'Programming languages, frameworks, and tools', 'code'),
  ('Soft Skills', 'Interpersonal and communication abilities', 'users'),
  ('Domain', 'Subject-specific knowledge areas', 'book'),
  ('Aptitude', 'Analytical and problem-solving skills', 'brain')
ON CONFLICT (name) DO NOTHING;

-- ============ SKILLS ============
DO $$
DECLARE
  tech_id uuid;
  soft_id uuid;
  domain_id uuid;
  apt_id uuid;
BEGIN
  SELECT id INTO tech_id FROM skill_categories WHERE name = 'Technical';
  SELECT id INTO soft_id FROM skill_categories WHERE name = 'Soft Skills';
  SELECT id INTO domain_id FROM skill_categories WHERE name = 'Domain';
  SELECT id INTO apt_id FROM skill_categories WHERE name = 'Aptitude';

  INSERT INTO skills (name, category_id, description)
  SELECT 'JavaScript', tech_id, 'Core JavaScript programming'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'JavaScript');

  INSERT INTO skills (name, category_id, description)
  SELECT 'React', tech_id, 'React UI library'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'React');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Node.js', tech_id, 'Server-side JavaScript runtime'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Node.js');

  INSERT INTO skills (name, category_id, description)
  SELECT 'MongoDB', tech_id, 'NoSQL database'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'MongoDB');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Python', tech_id, 'Python programming language'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Python');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Java', tech_id, 'Java programming language'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Java');

  INSERT INTO skills (name, category_id, description)
  SELECT 'SQL', tech_id, 'Relational database querying'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'SQL');

  INSERT INTO skills (name, category_id, description)
  SELECT 'TypeScript', tech_id, 'Typed JavaScript superset'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'TypeScript');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Express.js', tech_id, 'Node.js web framework'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Express.js');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Cloud Computing', tech_id, 'Cloud platforms and services'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Cloud Computing');

  INSERT INTO skills (name, category_id, description)
  SELECT 'AI/ML', tech_id, 'Artificial Intelligence and Machine Learning'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'AI/ML');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Communication', soft_id, 'Verbal and written communication'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Communication');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Leadership', soft_id, 'Team leadership and management'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Leadership');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Problem Solving', soft_id, 'Analytical problem-solving'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Problem Solving');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Data Analysis', domain_id, 'Data analysis and interpretation'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Data Analysis');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Project Management', soft_id, 'Managing project timelines and deliverables'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Project Management');

  INSERT INTO skills (name, category_id, description)
  SELECT 'Cybersecurity', domain_id, 'Security principles and practices'
  WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Cybersecurity');
END $$;

-- ============ ASSESSMENTS ============
DO $$
DECLARE
  tech_cat_id uuid;
  soft_cat_id uuid;
  apt_cat_id uuid;
  js_skill_id uuid;
  react_skill_id uuid;
  py_skill_id uuid;
  comm_skill_id uuid;
BEGIN
  SELECT id INTO tech_cat_id FROM skill_categories WHERE name = 'Technical';
  SELECT id INTO soft_cat_id FROM skill_categories WHERE name = 'Soft Skills';
  SELECT id INTO apt_cat_id FROM skill_categories WHERE name = 'Aptitude';
  SELECT id INTO js_skill_id FROM skills WHERE name = 'JavaScript';
  SELECT id INTO react_skill_id FROM skills WHERE name = 'React';
  SELECT id INTO py_skill_id FROM skills WHERE name = 'Python';
  SELECT id INTO comm_skill_id FROM skills WHERE name = 'Communication';

  INSERT INTO assessments (title, description, category_id, skill_id, assessment_type, difficulty, time_limit_minutes, passing_score, is_active)
  SELECT 'JavaScript Fundamentals', 'Test your knowledge of core JavaScript concepts including variables, functions, and data types.',
    tech_cat_id, js_skill_id, 'technical', 'intermediate', 20, 50, true
  WHERE NOT EXISTS (SELECT 1 FROM assessments WHERE title = 'JavaScript Fundamentals');

  INSERT INTO assessments (title, description, category_id, skill_id, assessment_type, difficulty, time_limit_minutes, passing_score, is_active)
  SELECT 'React Developer Assessment', 'Evaluate your React skills including components, hooks, state management, and routing.',
    tech_cat_id, react_skill_id, 'technical', 'intermediate', 25, 50, true
  WHERE NOT EXISTS (SELECT 1 FROM assessments WHERE title = 'React Developer Assessment');

  INSERT INTO assessments (title, description, category_id, skill_id, assessment_type, difficulty, time_limit_minutes, passing_score, is_active)
  SELECT 'Python Programming Test', 'Assess your Python knowledge including syntax, data structures, and OOP concepts.',
    tech_cat_id, py_skill_id, 'technical', 'intermediate', 20, 50, true
  WHERE NOT EXISTS (SELECT 1 FROM assessments WHERE title = 'Python Programming Test');

  INSERT INTO assessments (title, description, category_id, skill_id, assessment_type, difficulty, time_limit_minutes, passing_score, is_active)
  SELECT 'Communication Skills Assessment', 'Evaluate your communication abilities including verbal, written, and interpersonal skills.',
    soft_cat_id, comm_skill_id, 'soft_skills', 'beginner', 15, 50, true
  WHERE NOT EXISTS (SELECT 1 FROM assessments WHERE title = 'Communication Skills Assessment');

  INSERT INTO assessments (title, description, category_id, skill_id, assessment_type, difficulty, time_limit_minutes, passing_score, is_active)
  SELECT 'Problem Solving & Aptitude', 'Test your analytical thinking and problem-solving abilities.',
    apt_cat_id, NULL, 'aptitude', 'intermediate', 20, 50, true
  WHERE NOT EXISTS (SELECT 1 FROM assessments WHERE title = 'Problem Solving & Aptitude');
END $$;

-- ============ ASSESSMENT QUESTIONS ============
DO $$
DECLARE
  js_assess_id uuid;
  react_assess_id uuid;
  py_assess_id uuid;
  comm_assess_id uuid;
  apt_assess_id uuid;
BEGIN
  SELECT id INTO js_assess_id FROM assessments WHERE title = 'JavaScript Fundamentals';
  SELECT id INTO react_assess_id FROM assessments WHERE title = 'React Developer Assessment';
  SELECT id INTO py_assess_id FROM assessments WHERE title = 'Python Programming Test';
  SELECT id INTO comm_assess_id FROM assessments WHERE title = 'Communication Skills Assessment';
  SELECT id INTO apt_assess_id FROM assessments WHERE title = 'Problem Solving & Aptitude';

  -- JavaScript questions
  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT js_assess_id, 'Which keyword is used to declare a constant in JavaScript?', 'mcq', '["var","let","const","static"]', 'const', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which keyword is used to declare a constant in JavaScript?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT js_assess_id, 'What is the output of: typeof null in JavaScript?', 'mcq', '["null","undefined","object","number"]', 'object', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is the output of: typeof null in JavaScript?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT js_assess_id, 'Which method converts a JSON string to an object?', 'mcq', '["JSON.parse()","JSON.stringify()","JSON.toObject()","JSON.convert()"]', 'JSON.parse()', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which method converts a JSON string to an object?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT js_assess_id, 'What does the === operator check in JavaScript?', 'mcq', '["Only value","Only type","Both value and type","Neither"]', 'Both value and type', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What does the === operator check in JavaScript?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT js_assess_id, 'Which array method creates a new array with results of a function?', 'mcq', '["forEach()","map()","filter()","reduce()"]', 'map()', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which array method creates a new array with results of a function?');

  -- React questions
  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT react_assess_id, 'Which hook manages state in functional components?', 'mcq', '["useEffect","useState","useContext","useRef"]', 'useState', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which hook manages state in functional components?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT react_assess_id, 'What is JSX?', 'mcq', '["A JavaScript library","A syntax extension for JavaScript","A CSS framework","A build tool"]', 'A syntax extension for JavaScript', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is JSX?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT react_assess_id, 'Which hook is used for side effects in React?', 'mcq', '["useState","useEffect","useMemo","useCallback"]', 'useEffect', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which hook is used for side effects in React?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT react_assess_id, 'How do you pass data from parent to child component?', 'mcq', '["Through state","Through props","Through context","Through refs"]', 'Through props', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'How do you pass data from parent to child component?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT react_assess_id, 'What does the virtual DOM do?', 'mcq', '["Directly updates browser DOM","Keeps a copy in memory for efficient updates","Is a backup of the real DOM","Has no real purpose"]', 'Keeps a copy in memory for efficient updates', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What does the virtual DOM do?');

  -- Python questions
  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT py_assess_id, 'How do you create a list in Python?', 'mcq', '["list = ()","list = []","list = {}","list = <>"]', 'list = []', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'How do you create a list in Python?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT py_assess_id, 'Which keyword defines a function in Python?', 'mcq', '["function","def","func","define"]', 'def', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which keyword defines a function in Python?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT py_assess_id, 'What is the correct way to handle exceptions in Python?', 'mcq', '["try-catch","try-except","begin-rescue","do-catch"]', 'try-except', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is the correct way to handle exceptions in Python?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT py_assess_id, 'Which data type is immutable in Python?', 'mcq', '["list","dict","tuple","set"]', 'tuple', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which data type is immutable in Python?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT py_assess_id, 'What does len() function return?', 'mcq', '["The last element","The number of items","The first element","The type"]', 'The number of items', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What does len() function return?');

  -- Communication questions
  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT comm_assess_id, 'What is active listening?', 'mcq', '["Hearing without responding","Fully focusing and responding thoughtfully","Thinking about what to say next","Taking notes only"]', 'Fully focusing and responding thoughtfully', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is active listening?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT comm_assess_id, 'Which is an example of non-verbal communication?', 'mcq', '["An email","Body language","A phone call","A text message"]', 'Body language', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'Which is an example of non-verbal communication?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT comm_assess_id, 'What should you do before sending a professional email?', 'mcq', '["Send it immediately","Proofread for errors","Add emojis","Make it very long"]', 'Proofread for errors', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What should you do before sending a professional email?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT comm_assess_id, 'What is the key to effective presentation?', 'mcq', '["Speaking fast","Using complex jargon","Clear structure and audience awareness","Reading from slides"]', 'Clear structure and audience awareness', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is the key to effective presentation?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT comm_assess_id, 'How should you handle disagreement in a team meeting?', 'mcq', '["Argue loudly","Stay silent","Express views respectfully and listen","Leave the meeting"]', 'Express views respectfully and listen', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'How should you handle disagreement in a team meeting?');

  -- Problem Solving questions
  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT apt_assess_id, 'What comes next: 2, 4, 8, 16, ?', 'mcq', '["18","24","32","20"]', '32', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What comes next: 2, 4, 8, 16, ?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT apt_assess_id, 'A is father of B. But B is not son of A. How is B related to A?', 'mcq', '["Nephew","Daughter","Cousin","Niece"]', 'Daughter', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'A is father of B. But B is not son of A. How is B related to A?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT apt_assess_id, 'If you rearrange CIFAIPC, you get the name of a:', 'mcq', '["City","Country","Ocean","Animal"]', 'Ocean', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'If you rearrange CIFAIPC, you get the name of a:');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT apt_assess_id, 'What is the next number: 1, 1, 2, 3, 5, 8, ?', 'mcq', '["11","13","15","10"]', '13', 1, 'beginner'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'What is the next number: 1, 1, 2, 3, 5, 8, ?');

  INSERT INTO assessment_questions (assessment_id, question_text, question_type, options, correct_answer, weight, difficulty)
  SELECT apt_assess_id, 'If all roses are flowers and some flowers fade quickly, can we conclude some roses fade quickly?', 'mcq', '["Yes","No","Cannot be determined","Only if stated explicitly"]', 'Cannot be determined', 1, 'intermediate'
  WHERE NOT EXISTS (SELECT 1 FROM assessment_questions WHERE question_text = 'If all roses are flowers and some flowers fade quickly, can we conclude some roses fade quickly?');
END $$;

-- ============ LEARNING PROGRAMS ============
DO $$
BEGIN
  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'JavaScript Fundamentals', 'Master the basics of JavaScript including ES6+ features, DOM manipulation, and async programming.',
    '["JavaScript","Problem Solving"]', 'beginner', 6, 'freeCodeCamp', true, 'https://www.freecodecamp.org', 'Free', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'JavaScript Fundamentals');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'React - The Complete Guide', 'Learn React from scratch with hooks, context, routing, and state management.',
    '["React","JavaScript","TypeScript"]', 'intermediate', 10, 'Udemy', true, 'https://www.udemy.com', 'Paid', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'React - The Complete Guide');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'Python for Everybody', 'Comprehensive Python course covering syntax, data structures, OOP, and web scraping.',
    '["Python","Data Analysis"]', 'beginner', 8, 'Coursera', true, 'https://www.coursera.org', 'Free', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'Python for Everybody');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'MongoDB Basics', 'Learn MongoDB from installation to CRUD operations, aggregation, and indexing.',
    '["MongoDB","SQL","Node.js"]', 'beginner', 4, 'MongoDB University', true, 'https://university.mongodb.com', 'Free', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'MongoDB Basics');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'Effective Communication Skills', 'Develop your verbal, written, and interpersonal communication abilities.',
    '["Communication","Leadership"]', 'beginner', 4, 'LinkedIn Learning', true, 'https://www.linkedin.com/learning', 'Paid', 'Soft Skills'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'Effective Communication Skills');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'Data Analysis with Python', 'Learn pandas, numpy, and matplotlib for data analysis and visualization.',
    '["Python","Data Analysis","AI/ML"]', 'intermediate', 8, 'IBM', true, 'https://www.coursera.org', 'Free', 'Domain'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'Data Analysis with Python');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'AWS Cloud Practitioner', 'Introduction to AWS cloud services, architecture, and best practices.',
    '["Cloud Computing","Project Management"]', 'beginner', 6, 'AWS Training', true, 'https://aws.amazon.com/training', 'Paid', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'AWS Cloud Practitioner');

  INSERT INTO learning_programs (title, description, skills_taught, level, duration_weeks, provider, certification_available, url, cost, category)
  SELECT 'SQL Database Fundamentals', 'Master SQL queries, joins, subqueries, and database design.',
    '["SQL","Data Analysis"]', 'beginner', 5, 'Khan Academy', false, 'https://www.khanacademy.org', 'Free', 'Technical'
  WHERE NOT EXISTS (SELECT 1 FROM learning_programs WHERE title = 'SQL Database Fundamentals');
END $$;